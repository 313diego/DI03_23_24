/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jpanelimagen;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author diego
 */
public class JPanelImagen extends JPanel implements Serializable {

    private ImagenFondo imagenFondo = ImagenFondoPanel.getImagenFondo();
    private boolean ratonPresionado = false;
    private Point puntoPresion;
    private boolean contador = false;

    public JPanelImagen() {

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                
                if(ratonPresionado){
                    Point puntoFinal = e.getPoint();
                    if(Math.abs(puntoPresion.y - puntoFinal.y) > 50){
                        contador = (contador) ? false : true;
                        repaint();
                    }
                }
                
                ratonPresionado = false;
            }

            @Override
            public void mousePressed(MouseEvent e) {
                ratonPresionado = true;
                puntoPresion = e.getPoint();
            }

        });

    }

    public ImagenFondo getImagenFondo() {
        return imagenFondo;
    }

    public void setImagenFondo(ImagenFondo imagenFondo) {
        this.imagenFondo = imagenFondo;
    }

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);
        
        if (imagenFondo != null) {
            
            File rutaMostrada;
            float opaMostrada;
            
            if(!contador){
                
                rutaMostrada = imagenFondo.getRutaImgInicial();
                opaMostrada = imagenFondo.getOpaInicial();
                
                
            }else{
                
                rutaMostrada = imagenFondo.getRutaImgFinal();
                opaMostrada = imagenFondo.getOpaFinal();
                
            } 
            
            if (imagenFondo.getRutaImgInicial() != null && imagenFondo.getRutaImgInicial().exists()) {
                ImageIcon imageIcon = new ImageIcon (rutaMostrada.getAbsolutePath());
                Graphics2D g2d = (Graphics2D) g;
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
                        opaMostrada));
                g.drawImage(imageIcon.getImage(), 0, 0, getWidth(), getHeight(), this);
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
            }
        }
    }

}
