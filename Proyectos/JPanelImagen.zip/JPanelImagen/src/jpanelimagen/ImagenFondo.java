/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jpanelimagen;

import java.io.File;
import java.io.Serializable;

/**
 *
 * @author diego
 */
public class ImagenFondo implements Serializable {
    
    private File rutaImgInicial;
    private File rutaImgFinal;
    private float opaInicial;
    private float opaFinal;
    
    public ImagenFondo() {
    }
    
    public ImagenFondo(File rutaImgInicial, float opaInicial, File rutaImgFinal, float opaFinal) {
        this.rutaImgInicial = rutaImgInicial;
        this.opaInicial = opaInicial;
        this.rutaImgFinal = rutaImgFinal;
        this.opaFinal = opaFinal;
    }
    
    public File getRutaImgInicial() {
        return rutaImgInicial;
    }

    public void setRutaImgInicial(File rutaImgInicial) {
        this.rutaImgInicial = rutaImgInicial;
    }

    public File getRutaImgFinal() {
        return rutaImgFinal;
    }

    public void setRutaImgFinal(File rutaImgFinal) {
        this.rutaImgFinal = rutaImgFinal;
    }

    public float getOpaInicial() {
        return opaInicial;
    }

    public void setOpaInicial(float opaInicial) {
        this.opaInicial = opaInicial;
    }

    public float getOpaFinal() {
        return opaFinal;
    }

    public void setOpaFinal(float opaFinal) {
        this.opaFinal = opaFinal;
    }
    
    
    
}
